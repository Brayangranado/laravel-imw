*It's hard to solve a problem when important details are missing, that why we added this template, to help you and us.*

### General informations
Operating system :  
Perl version :

### OCS Inventory informations
Unix agent version : 

### Problem's description
*Describe your problem here*

### Inventory log file ( optional )
*Use github cloud or trusted upload website*
